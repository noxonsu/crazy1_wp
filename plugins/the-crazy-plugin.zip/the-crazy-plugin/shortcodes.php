<?php

function heart_icon () { 
    $result = '<i class="fa fa-fw fa-heart-o"></i>'; 
return $result;}
add_shortcode('heart', 'heart_icon');

function video_shortcode( $atts, $content = null ) {
   extract( shortcode_atts( array(
      'vimeo' => '',
	  'img' => '',
      ), $atts ) );
    return '<div class="mt40 mb40"><div class="row"><div class="col-sm-4 sm-mb40"><div class="blog-video-wrap"><img src="' . esc_attr($img) . '" alt="image"><div class="blog-video-content"><a href="' . esc_attr($vimeo) . '" class="btn btn-white btn-play popup-video"><span><i class="fa fa-play"></i></span></a></div></div></div><div class="col-sm-8">' . $content . '</div></div></div>';
}
add_shortcode('video', 'video_shortcode');

function row_shortcode($atts, $content = null ) {
    return '<div class="mt80">
	            <div class="row">' . do_shortcode($content) . '</div>
			</div>';
}
add_shortcode('row', 'row_shortcode');

function row_img_shortcode( $atts ) {
   extract( shortcode_atts( array(
      'img' => '',
	  'alt' => '',
      ), $atts ) );
    return '<div class="col-sm-4 sm-mb30" data-sr>
			    <img src="' . esc_attr($img) . '" alt="' . esc_attr($alt) . '">
			</div>';
}
add_shortcode('row_img', 'row_img_shortcode');

function thumb_shortcode( $atts ) {
   extract( shortcode_atts( array(
      'img' => '',
	  'alt' => '',
      ), $atts ) );
    return '<div class="thumb">
			    <img src="' . esc_attr($img) . '" alt="' . esc_attr($alt) . '">
		    </div>';
}
add_shortcode('thumb', 'thumb_shortcode');

function rowt_shortcode($atts, $content = null ) {
    return '<div class="thumb">
			    <div class="row">' . do_shortcode($content) . '</div>
			</div>';
}
add_shortcode('rowt', 'rowt_shortcode');

?>