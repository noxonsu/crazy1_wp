<?php
/*
Plugin Name: the_crazy_plugin
Description: Template Settings "The crazy"
Version: 1.0.
Author: torss27
*/

include_once "shortcodes.php";
include_once "import_demo.php";
include_once('advanced-custom-fields/acf.php');
include_once('advanced-custom-fields/acf-repeater/acf-repeater.php');

?>