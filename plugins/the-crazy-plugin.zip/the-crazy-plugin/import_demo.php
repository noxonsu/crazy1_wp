<?php

if ( !defined('ABSPATH') ) {
	/** Set up WordPress environment */
	require_once( dirname( __FILE__ ) . '/../../../wp-load.php' );
}

function mycity_my_appearance_menu_item()
{
    add_theme_page('Import demo data','Import demo data', 'edit_theme_options', 'mycity_wp_importer_geocity244',
        'mycity_wp_importer_geocity');
}

add_action('admin_menu', 'mycity_my_appearance_menu_item');


function mycity_wp_importer_geocity()
{
    global $_POST;
    if (isset($_POST['wfm_hidenn']) && $_POST['wfm_hidenn'] == 'wmf_hiden') {


        global $wpdb, $wp_filesystem;

        /*
         * uploads files
         */
        if (empty($wp_filesystem)) {
            require_once(ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }

        //dowload files
        $tmp_files = download_url('http://crazy1.wpmix.net/2016.zip');

        if (is_wp_error($tmp_files)) {
            $tmp_files->get_error_messages();

        } else {
            $destination = wp_upload_dir();
            unzip_file($tmp_files, $destination['basedir']);
        }
        /*
         * SQL
         */
		 

        global $wpdb;
        //$wpdb->show_errors();
        $wpdb->hide_errors();
        /*********************************************************************************/
        $filename = plugin_dir_path(__FILE__) . 'demo/vioo_wp.sql';
		
        ($fp = fopen($filename, 'r'));
        $wpdb->hide_errors();
        $query = '';

        while ($line = fgets($fp)) {
            if (substr($line, 0, 2) == '--' OR trim($line) == '') {
                continue;
            }
            $query .= mb_convert_encoding($line, "UTF-8");
            $query = str_replace(
			       array(
				       'http://localhost/php2',
					   'wp_comments',
					   'wp_options',
					   'wp_postmeta',
					   'wp_posts',
					   'wp_terms',
					   'wp_term_relationships',
					   'wp_term_taxonomy',
					   'wp_commentmeta',
					   'wp_links',
					   'wp_termmeta',
					   'wp_usermeta',
					   'wp_users'
				   ), 
				   array(
				       get_home_url(''),
					   ''.$wpdb->prefix.'comments',
					   ''.$wpdb->prefix.'options',
					   ''.$wpdb->prefix.'postmeta',
					   ''.$wpdb->prefix.'posts',
					   ''.$wpdb->prefix.'terms',
					   ''.$wpdb->prefix.'term_relationships',
					   ''.$wpdb->prefix.'term_taxonomy',
					   ''.$wpdb->prefix.'commentmeta',
					   ''.$wpdb->prefix.'links',
					   ''.$wpdb->prefix.'termmeta',
					   ''.$wpdb->prefix.'usermeta',
					   ''.$wpdb->prefix.'users',
				   )
			, $query);
            if (substr(trim($query), -1) == ';') {
                if (!$wpdb->query($query)) {
                }
                $query = '';
            }
        }
		
		update_option('page_on_front', 13);
		update_option('show_on_front', 'page');
		set_theme_mod ('copyright', '<p>Copyright &copy; 2016. Design by <a href="#">Unvab</a> Coded by <a href="#">VLThemes</a></p>' );
		set_theme_mod ('linkto1', '#' );
		set_theme_mod ('linkto2', '#' );
		set_theme_mod ('linkto3', '#' );
		set_theme_mod ('linkto4', '#' );
		set_theme_mod ('linkto5', '#' );
		set_theme_mod ('image_404', get_home_url().'/wp-content/uploads/2016/05/bg13-1.png' );
		set_theme_mod ('index_img', get_home_url().'/wp-content/uploads/2016/05/bg11-1.png' );
		set_theme_mod ('background_p', get_home_url().'/wp-content/uploads/2016/05/bg13-1.png' );
		set_theme_mod ('pogination_on', 'ajax' );
		$foo = 2;
		$locations = array();
        $locations['primary'] = $foo;
        set_theme_mod('nav_menu_locations', $locations);
		
        ?>
        <div class="updated below-h2 rs-update-notice-wrap" id="message">

            <p>
                <?php
                 esc_html_e('Import was successful. ReActivate all plugins!', 'crazy')
                ?>
            </p></div>
        <?php
    }
    ?>
    <div style="padding:20px;background-color:white;

        margin-bottom: 2px;
margin-left: 15px;
margin-right: 15px;
margin-top: 5px;
        ">
        <?php
        esc_html_e('Press the button for import', 'crazy')
        ?>

        <form action="" method="post">
            <table border="0" width="600">

                <input type="hidden" name="wfm_hidenn" value="wmf_hiden"/>
                <tbody>

                <tr> <?php


                    ?>
                    <span style="color: red; font-weight: bold"><?php esc_html_e('All exist data will be deleted!', 'crazy') ?></span>
                    <td colspan="2"><input type="submit" class='btn btn-primary primary' value="<?php esc_html_e('Import', 'crazy') ?>"/></td>
                </tr>
                </tbody>
            </table>
        </form>
    </div>
    <?php
}

?>